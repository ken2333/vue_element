import {getApiUrl as G} from '../utils/request'

export default {
  fileUpload: G('FileUpload','post'),
}
