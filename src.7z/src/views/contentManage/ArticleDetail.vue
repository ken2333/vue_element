<template>
        <el-container>
                <el-header >
                        <p class="title">{{titile}}</p>
                        <p class="arrticleInfo"><span>作者:{{authorID}}</span>   发布时间：{{createtime}}  游览量：{{pageview}}</p>
                </el-header>

                <el-main><div v-html="content"></div>


                </el-main>

        </el-container>

</template>

<script>
    export default {
        name: "ArticleDetail",
        data:function()
        {
            return {
                content:``,
                titile:"",
                articleID:"",
                authorID:"",
                pageview:1,
                createtime:"",
                tableData:[]
            }
        },
        created:function () {
            let id=this.$router.currentRoute.query.id;
            this.$axios.post("/api/article/getById",{id:id}).then(res=>{
                let data=res.data;
                this.createtime=new Date(data.createtime).toLocaleString();
                this.pageview=data.pageview;
                this.authorID=data.author;
                this.articleID=data.id;
                this.content=data.content;
                this.titile=data.titile;
            }).catch(
            )
        }
    }
</script>

<style scoped>
  .title {
          font-size: 24px;
          word-wrap: break-word;
          text-align: center;
  }
   .arrticleInfo{
           text-align: right;
   }
  .comments{
                background: white;
                border: #6c75b8 2px solid;
                border-radius: 4px;
                margin-top: 50px;

                width: 100%;

        }
   .comments .comment
   {
        margin: 20px;
   }
  .comments .comment  .personInfo
  {
          text-align: center;
          width: 10%;
          float: left;
  }
  .comments .comment .words
  {
          width: 85%;
          float: right;
  }
  .time {
          text-align: right;
          position: relative;
          bottom:-90px;
  }

</style>